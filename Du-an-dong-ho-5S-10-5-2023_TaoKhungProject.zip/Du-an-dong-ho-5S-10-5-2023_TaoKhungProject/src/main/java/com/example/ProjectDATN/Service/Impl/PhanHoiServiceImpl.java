package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.PhanHoiService;
import org.springframework.stereotype.Service;

@Service
public class PhanHoiServiceImpl implements PhanHoiService {
}
