package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.AnhSanPhamService;
import org.springframework.stereotype.Service;

@Service
public class AnhSanPhamServiceImpl implements AnhSanPhamService {
}
