package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.DanhMucService;
import org.springframework.stereotype.Service;

@Service
public class DanhMucServiceImpl implements DanhMucService {
}
