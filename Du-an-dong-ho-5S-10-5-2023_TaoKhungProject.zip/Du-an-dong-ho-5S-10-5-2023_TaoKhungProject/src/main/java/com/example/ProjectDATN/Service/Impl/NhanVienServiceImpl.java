package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.NhanVienService;
import org.springframework.stereotype.Service;

@Service
public class NhanVienServiceImpl implements NhanVienService {
}
