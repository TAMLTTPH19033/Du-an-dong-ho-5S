package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.SanPhamService;
import org.springframework.stereotype.Service;

@Service
public class SanPhamServiceImpl implements SanPhamService {
}
