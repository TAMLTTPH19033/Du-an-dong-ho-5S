package com.example.ProjectDATN.Service;

public interface KhachHangService {
}
