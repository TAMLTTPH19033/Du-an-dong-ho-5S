package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.KichCoService;
import org.springframework.stereotype.Service;

@Service
public class KichCoServiceImpl implements KichCoService {
}
