package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.KhuyenMaiService;
import org.springframework.stereotype.Service;

@Service
public class KhuyenMaiServiceImpl implements KhuyenMaiService {
}
