package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.KhachHangService;
import org.springframework.stereotype.Service;

@Service
public class KhachHangServiceImpl implements KhachHangService {
}
