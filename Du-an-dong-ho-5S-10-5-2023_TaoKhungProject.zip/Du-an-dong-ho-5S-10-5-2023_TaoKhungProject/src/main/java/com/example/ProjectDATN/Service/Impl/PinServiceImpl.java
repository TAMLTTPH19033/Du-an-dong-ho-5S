package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.PinService;
import com.example.ProjectDATN.Service.VatLieuService;
import org.springframework.stereotype.Service;

@Service
public class PinServiceImpl implements PinService {
}
