package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.DayDeoService;
import org.springframework.stereotype.Service;

@Service
public class DayDeoServiceImpl implements DayDeoService {
}
