package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.SeriService;
import org.springframework.stereotype.Service;

@Service
public class SeriServiceImpl implements SeriService {
}
