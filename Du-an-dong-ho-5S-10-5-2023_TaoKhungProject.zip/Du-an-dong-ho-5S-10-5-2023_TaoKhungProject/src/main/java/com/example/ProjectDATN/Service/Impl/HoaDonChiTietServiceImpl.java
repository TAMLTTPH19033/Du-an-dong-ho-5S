package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.HoaDonChiTietService;
import org.springframework.stereotype.Service;

@Service
public class HoaDonChiTietServiceImpl implements HoaDonChiTietService {
}
