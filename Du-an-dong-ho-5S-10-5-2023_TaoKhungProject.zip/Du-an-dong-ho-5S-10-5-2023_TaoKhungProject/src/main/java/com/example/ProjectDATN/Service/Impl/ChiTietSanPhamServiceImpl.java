package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.ChiTietSanPhamService;
import org.springframework.stereotype.Service;

@Service
public class ChiTietSanPhamServiceImpl implements ChiTietSanPhamService {
}
