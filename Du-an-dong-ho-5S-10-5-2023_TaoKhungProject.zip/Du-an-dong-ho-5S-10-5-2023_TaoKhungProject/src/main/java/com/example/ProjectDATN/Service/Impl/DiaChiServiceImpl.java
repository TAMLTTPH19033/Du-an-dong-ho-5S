package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.DiaChiService;
import org.springframework.stereotype.Service;

@Service
public class DiaChiServiceImpl implements DiaChiService {
}
