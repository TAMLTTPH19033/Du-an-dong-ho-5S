package com.example.ProjectDATN.Configure;

import org.springframework.context.annotation.Configuration;


//@Configuration
//@EnableWebSecurity
public class SecurityConfigure  {

}
