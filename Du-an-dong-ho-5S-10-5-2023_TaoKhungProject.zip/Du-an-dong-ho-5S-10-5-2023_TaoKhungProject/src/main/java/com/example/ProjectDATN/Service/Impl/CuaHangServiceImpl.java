package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.CuaHangService;
import org.springframework.stereotype.Service;

@Service
public class CuaHangServiceImpl implements CuaHangService {
}
