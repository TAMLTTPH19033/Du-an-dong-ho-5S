package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.DonHangService;
import org.springframework.stereotype.Service;

@Service
public class DonHangServiceImpl implements DonHangService {
}
