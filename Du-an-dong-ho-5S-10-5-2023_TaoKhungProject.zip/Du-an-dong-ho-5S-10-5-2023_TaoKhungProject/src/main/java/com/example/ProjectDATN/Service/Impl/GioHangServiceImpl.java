package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.GioHangService;
import org.springframework.stereotype.Service;

@Service
public class GioHangServiceImpl implements GioHangService {
}
