package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.ChucVuService;
import org.springframework.stereotype.Service;

@Service
public class ChucVuServiceImpl implements ChucVuService {
}
