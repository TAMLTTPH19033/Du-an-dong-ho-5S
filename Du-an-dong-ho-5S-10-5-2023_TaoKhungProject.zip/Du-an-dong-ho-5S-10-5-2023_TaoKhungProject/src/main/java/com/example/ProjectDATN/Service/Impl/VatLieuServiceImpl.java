package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.VatLieuService;
import org.springframework.stereotype.Service;

@Service
public class VatLieuServiceImpl implements VatLieuService {
}
