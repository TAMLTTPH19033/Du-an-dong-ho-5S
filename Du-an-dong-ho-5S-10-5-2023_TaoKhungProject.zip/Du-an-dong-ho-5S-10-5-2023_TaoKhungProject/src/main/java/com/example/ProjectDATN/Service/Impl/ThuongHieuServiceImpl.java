package com.example.ProjectDATN.Service.Impl;

import com.example.ProjectDATN.Service.ThuongHieuService;
import org.springframework.stereotype.Service;

@Service
public class ThuongHieuServiceImpl implements ThuongHieuService {
}
